### Expected behavior

Write here what you're expecting ...

### Actual behavior

Write here what happens instead ...

### Steps to reproduce:

Please create a reproducible case of your problem. Re produce it 
with a minimal `vimrc` with all plugins disabled and only `vim-go`
enabled:

1.
2.
3.

### Configuration

#### `vimrc` you used to reproduce:

#### vim version: 

#### vim-go version:

#### go version:



