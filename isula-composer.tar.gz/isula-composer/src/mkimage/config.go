package main

import (
	"gopkg.in/yaml.v2"
)

type BaseRootfs struct {
	Kernel struct {
		Cmdline string
	}
	AddPackages []string
	RmPackages []string
	Files struct {
		Add [][]string
		Remove []string
	}
}

type AddonRootfs struct {
	InitRootfs struct {
		File string
	}
	Kernel struct {
		Cmdline string
	}
	Features []string
	AddPackages []string
	RmPackages []string
	SysContainers []struct {
		Name string
		Image string
	}
	AppContainers []struct {
		Name string
		Image string
	}
	Files struct {
		Add [][]string
		Remove []string
	}
	Outputs []string
}

func convert(i interface{}) interface{} {
	switch x := i.(type) {
	case map[interface{}]interface{}:
		m2 := map[string]interface{}{}
		for k, v := range x {
			m2[k.(string)] = convert(v)
		}
		return m2
	case []interface{}:
		for i, v := range x {
			x[i] = convert(v)
		}
	}
	return i
}

// NewConfig parses a config Files
func NewAddConfig(config []byte) (AddonRootfs, error) {
	m := AddonRootfs{}

	// Parse yaml
	err := yaml.Unmarshal(config, &m)
	if err != nil {
		return m, err
	}

	return m, nil
}

func NewBaseConfig(config []byte) (BaseRootfs, error) {
	m := BaseRootfs{}

	// Parse yaml
	err := yaml.Unmarshal(config, &m)
	if err != nil {
		return m, err
	}

	return m, nil
}
