BUILDDIR="$1"
SCRIPTDIR=$(pwd)
BUILDDIR=$(cd $BUILDDIR && pwd)

chroot "$SCRIPTDIR/rootfs-tmp" rpm -e kernel --noscripts
cd "$SCRIPTDIR/rootfs-tmp"
tar cvf Euler-docker.tar .
mv Euler-docker.tar "$BUILDDIR"
cd "$BUILDDIR"
cat << EOF > $BUILDDIR/Dockerfile

FROM scratch
ADD Euler-docker.tar /


LABEL name="EulerOS Base Image" \\
vendor="EulerOS" \\
license="GPLv2" \\
build-date="20170816"

CMD ["/bin/bash"]
EOF

