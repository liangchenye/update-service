#!/bin/sh

BaseDir=$1

cd ${BaseDir}/boot
vmlinuz=$(find . -name vmlinuz*)
initrd=$(find . -name initramfs*)
mkdir initrd-tmp
cd initrd-tmp
/usr/lib/dracut/skipcpio ../${initrd} | zcat | cpio -di
rm ../${initrd}
cp ${BaseDir}/usr/lib/systemd/system/ostree-prepare-root.service usr/lib/systemd/system/
mkdir usr/lib/ostree
cp ${BaseDir}/usr/lib/ostree/ostree-prepare-root usr/lib/ostree/
sed -i '/AllowIsolate/i\Requires=ostree-prepare-root.service' usr/lib/systemd/system/initrd-switch-root.service
sed -i '/AllowIsolate/i\After=ostree-prepare-root.service' usr/lib/systemd/system/initrd-switch-root.service
find . | cpio -c -o > ../${initrd}
cd ..
rm -rf initrd-tmp
gzip ${initrd}
mv ${initrd}.gz ${initrd}
bootcsum=$(cat ${vmlinuz} ${initrd} | sha256sum | cut -f 1 -d ' ')
mv ${vmlinuz} ${vmlinuz}-${bootcsum}
mv ${initrd} ${initrd}-${bootcsum}

cd ${BaseDir}
mkdir sysroot
ln -s sysroot/ostree ostree
rm -rf home
ln -s var/home home
rm -rf media
ln -s run/media media
rm -rf mnt
ln -s var/mnt mnt
rm -rf opt
ln -s var/opt opt
rm -rf root
ln -s var/roothome root
rm -rf srv
ln -s var/srv srv
rm -rf tmp
ln -s sysroot/tmp tmp
mkdir usr/share/rpm
cp -rf var/lib/rpm/* usr/share/rpm/
rm -rf var/lib/rpm/
mkdir -p usr/lib/ostree-boot
cp -rf boot/* usr/lib/ostree-boot/

# store local ostree repo in /etc/ostree/repo
mkdir -p usr/etc/ostree/repo
sed -i '2c url=file:///var/local/repo' usr/etc/ostree/remotes.d/euleros-antos-host.conf
sed -i 's/euleros-antos-host\/7/euleros-antos-host\/2/g' usr/etc/ostree/remotes.d/euleros-antos-host.conf

cp ../tools/ostree/rpm-ostree* usr/lib/tmpfiles.d/
cp ../tools/ostree/group usr/lib/
cp ../tools/ostree/passwd usr/lib/

# disable selinux currently to workaround one login problem
sed -i 's/SELINUX=enforcing/SELINUX=disabled/' usr/etc/selinux/config
