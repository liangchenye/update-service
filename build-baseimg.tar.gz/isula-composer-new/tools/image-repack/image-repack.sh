#!/bin/sh

function usage()
{
	echo "Usage: $self_path -i input_image -t image_type -o output_image"
	echo "Repack an OS image, supported image type: ISO"
}

function check_args()
{
	local iarg="$1"
	local oarg="$2"
	local targ="$3"

	if [ -z "$iarg" ] || [ -z "$oarg" ] || [ -z "$targ" ]; then
		usage
		return 1
	fi
}

function repack_qcow2()
{
	echo "repack $1 start"
	rootpart=`virt-filesystems -a $1 | grep root`
	mkdir -p /mnt/repack
	guestmount -a $1 -m $rootpart --rw /mnt/repack
	local copied_dir=/mnt/repack/ostree/deploy/euleros-antos-host/var/containers
	mkdir -p $copied_dir

	for files in `cat add-files`; do
		cp $files $copied_dir
	done

	sleep 10
    umount /mnt/repack
	rm -rf /mnt/repack
	echo "repack $1 finished"
}

function repack_iso()
{
	local inImage=$1
	local outImage=$2
	local curDir=`pwd`
	local mntDir=/mnt/repack
	local isoRoot=/tmp/iso-root
	local need_recreate=0

	# cleanup beforehand
	umount /mnt/repack/ >/dev/null 2>&1
	umount /tmp/iso-root/LiveOS/squashfs-root/LiveOS/tmp >/dev/null 2>&1
	rm -rf /tmp/iso-root

	type unsquashfs >/dev/null 2>&1 || { echo "Please install squashfs-tools package"; exit 1; }
	type ostree >/dev/null 2>&1 || { echo "Please install ostree package"; exit 1; }
	type mkisofs >/dev/null 2>&1 || { echo "Please install genisoimage package"; exit 1; }

	echo "repack ${inImage} start"
	mkdir -p $mntDir
	mkdir -p $isoRoot

	# determine if we need to adjust ISO rootfs size
	cd $curDir/rootfs
	size=$(du -h --max-depth=1 | awk 'END {print}' | awk 'END {print $1}')
	if [ ! -z `echo $size | grep G` ]; then
		size=$((${size//.*/+1}))
		count_G=`expr 2 + $size`
		need_recreate=1
	elif [ ! -z `echo $size | grep M` ]; then
		size=$(echo $size | sed 's/M//')
		if [ $size -gt 400 ]; then
			count_G=3
			need_recreate=1
		fi
	fi

	mount ${inImage} $mntDir
	cp -rf $mntDir/* $isoRoot
	cd $isoRoot/LiveOS
	unsquashfs squashfs.img
	cd $isoRoot/LiveOS/squashfs-root/LiveOS/
	mkdir tmp
	mount rootfs.img tmp
	if [ $need_recreate -eq 1 ]; then
		mkdir root
		dd if=/dev/zero of=root.img bs=1G count=$count_G
		echo "y" | mkfs.ext4 root.img
		mount root.img root
		cp -rf tmp/* root/
		umount tmp
		umount root
		rm -rf root
		rm rootfs.img
		mv root.img rootfs.img
		mount rootfs.img tmp
	fi

	cd tmp/install/ostree
	ref=$(ostree refs)
	commit=$(ostree --repo=$isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree log $ref | grep ^commit | cut -f 2 -d ' ')
	version=$(ostree --repo=$isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree log $ref | grep Version | cut -f 2 -d ' ')
	ostag=$(cat $isoRoot/EFI/BOOT/grub.cfg | grep search | sed -e 's/search --no-floppy --set=root -l //g' | sed -e "s/'//g")

	cd $isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree
	ostree --repo=$isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree export $commit > $curDir/rootfs-tmp.tar
	cd $curDir

	# create yum configuration file
	echo "[main]" >> yum.conf
	echo "cachedir=/var/yum/cache" >> yum.conf
	echo "reposdir=${curDir}" >> yum.conf
	echo "http_caching=none" >> yum.conf
	echo "keepcache=0" >> yum.conf
	echo "debuglevel=2" >> yum.conf
	echo "pkgpolicy=newest" >> yum.conf
	echo "tolerant=1" >> yum.conf
	echo "exactarch=1" >> yum.conf
	echo "obsoletes=1" >> yum.conf
	echo "plugins=0" >> yum.conf
	echo "deltarpm=0" >> yum.conf
	echo "metadata_expire=1800" >> yum.conf

	mkdir rootfs-tmp
	tar xvfo rootfs-tmp.tar -C rootfs-tmp
	cd rootfs-tmp/var/lib
	ln -s ../../usr/share/rpm rpm
	cd $curDir
	for pkg in `cat add-pkgs`; do
		yum install -y --config=yum.conf --installroot=$curDir/rootfs-tmp $pkg
		if [ ! -z `echo $pkg | grep dhcp` ]; then
			cp -rf $curDir/rootfs-tmp/var/lib/dhcpd $curDir/rootfs-tmp/etc/dhcp/
			echo "L /var/lib/dhcpd - - - - ../../etc/dhcp/dhcpd" >> $curDir/rootfs-tmp/usr/lib/tmpfiles.d/rpm-ostree-1-autovar.conf
			rm -rf $curDir/rootfs-tmp/var/lib/dhcpd
		fi
	done
	yum --config=yum.conf --installroot=$curDir/rootfs-tmp clean all

	# Adjust etc contents
	cp -rf rootfs-tmp/etc/* rootfs-tmp/usr/etc/
	rm -rf rootfs-tmp/etc/

	# cleanup
	rm -f rootfs-tmp/var/lib/rpm
	rm -rf rootfs-tmp/var/yum/cache
	rm -f yum.conf
	rm -f rootfs-tmp.tar

	if [ -s del-files ]; then
		for file in `cat del-files`; do
			rm -rf rootfs-tmp/$file
		done
		rm -rf $isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree/*
		ostree --repo=$isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree init --mode=archive-z2
	fi
	ostree --repo=$isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree commit \
		--branch=${ref} --add-metadata-string=version=${version} --tree=dir=${curDir}/rootfs-tmp
	ostree --repo=$isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree commit --tree=ref=${ref} \
		--branch=${ref} --add-metadata-string=version=${version} --tree=dir=${curDir}/rootfs
	ostree --repo=$isoRoot/LiveOS/squashfs-root/LiveOS/tmp/install/ostree summary -u

	rm -rf rootfs-tmp

	cd $isoRoot/LiveOS/squashfs-root/LiveOS/
	umount tmp
	rm -rf tmp
	cd ../..
	rm squashfs.img
	mksquashfs squashfs-root squashfs.img
	rm -rf squashfs-root/
	cd $isoRoot
	rm isolinux/boot.cat
	cd ${curDir}
	mkisofs -o ${outImage} -c isolinux/boot.cat -b isolinux/isolinux.bin -boot-load-size 4 -boot-info-table \
	-no-emul-boot -eltorito-alt-boot -e images/efiboot.img -no-emul-boot -R -J -V "$ostag" \
	-T -graft-points isolinux=$isoRoot/isolinux/ images/pxeboot=$isoRoot/images/pxeboot/ \
	LiveOS=$isoRoot/LiveOS/ EFI/BOOT=$isoRoot/EFI/BOOT/ images/efiboot.img=$isoRoot/images/efiboot.img

	umount $mntDir
	rm -rf $mntDir
	rm -rf $isoRoot
}

while getopts "i:o:t:" option 2>/dev/null
do
		case $option in
        i)
                input=$OPTARG
                ;;
        o)
				output=$OPTARG
                ;;
        t)
				type=$OPTARG
                ;;
        *)
                usage
                exit 1
                ;;
        esac
done

check_args $input $output $type
[ $? != 0 ] && exit 1

if [ "$type" == "iso" ]; then
	repack_iso $input $output
fi
